package Ass2;

public interface Colorable {
    void howToColor();
}
