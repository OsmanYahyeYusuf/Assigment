package Ass2;

public abstract class GeometricObject {
    public abstract double getArea();
}