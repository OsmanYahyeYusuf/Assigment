package Advance_java;

public class SavingAccounts extends Account{

    public SavingAccounts(String accountNumber, double balance, String fullName) {
        super(accountNumber, balance, fullName);
    }

    @Override
    public void withdraw(double amount) {
        super.withdraw(amount);

    }
}