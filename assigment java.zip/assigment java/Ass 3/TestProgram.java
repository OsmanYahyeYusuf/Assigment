package Assigment;

public class TestProgram {

        public static void main(String[] args) {
            Person person = new Person("Osman yahye", "heliwa", "6177275", "Osman@gmail.com");
            Student student = new Student("cali farax", "xamar jadiid", "615552", "cali@example.com", Student.FRESHMAN);
            MyDate dateHired = new MyDate("2024-01-02"); // Assuming this is correctly implemented
            Employee employee = new Employee("faarax shirwac", "hodan", "6188289", "osman@example.com", "HR", 100, dateHired);
            Faculty faculty = new Faculty("Fadumo yahye", "xamer weyne", "617788", "fadumo@gmai.com","Manager office", 150, dateHired, "8","2");
            Staff staff = new Staff("hamze yalaxow", "km4", "6178888", "hamze@gmail.com","Fanatial", 200, dateHired, "cashier");

            System.out.println(person);
            System.out.println(student);
            System.out.println(employee);
            System.out.println(faculty);
            System.out.println(staff);

        }
    }


